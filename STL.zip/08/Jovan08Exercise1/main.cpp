#include<iostream>
#include<vector>
#include<vector>
#include<numeric>

using namespace std;

class Employee
{
public:
    string name;
    int points;

    Employee(string empName,int empPoints) : name(empName), points(empPoints) {}
};

int calculateTotalSalary(const vector<Employee>& employees,int valuePerPoint)
{
    int totalSalary = 0;
    for(const auto& emp : employees)
    {
        totalSalary += emp.points * valuePerPoint;
    }

    return totalSalary;
}

int main()
{
    vector<Employee> employees =
    {
    {"Jovan",15}, {"Goce", 20}, {"Zoki", 18}
    };
    int valuePerPoint = 100;

    sort(employees.begin(), employees.end(), [](const Employee& a, const Employee& b)
    {
        return a.points > b.points;
    });


    int totalSalary = calculateTotalSalary(employees, valuePerPoint);


    cout << "Total salary for the company: " << totalSalary << endl;

    cout << "Employees sorted by points:" << endl;
    for (const auto& emp : employees)
    {
        cout << emp.name << " - Points: " << emp.points << endl;
    }

    return 0;
}
