#include<iostream>
#include<vector>

using namespace std;

template<typename T>
bool palindrom(const vector<T>& vec)
{
    size_t size = vec.size();
    for(size_t i = 0; i < size/2;i++)
    {
        if(vec[i] != vec[size-1-i])
        {
            return false;
        }
    }
    return true;
}

int main()
{
    vector<int> numbers = {1,2,3,2,1};
    vector<char> chars = {'a','b','c','b','a'};

    if (palindrom(numbers))
    {
        cout << "Palindrom" << endl;
    } else
    {
        cout << "Not palindrom" << endl;
    }

    if (palindrom(chars))
    {
        cout << "Palindrom" << endl;
    } else
    {
        cout << "Not palindrom" << endl;
    }

    return 0;
}
