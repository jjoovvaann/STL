#include<iostream>
#include<deque>
#include<vector>
#include<algorithm>

using namespace std;

int main()
{
    deque<int> d = {1,2,3,4,5};

    vector<int> v(d.rbegin(), d.rend());

    cout<<"Reversed: ";
    for(const auto& num : v)
    {
        cout<< num << " ";
    }
    cout<< endl;

    return 0;
}
