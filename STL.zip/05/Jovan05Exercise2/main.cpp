#include<iostream>
#include<list>
#include<unordered_set>

using namespace std;

list<string> mergeUnique(const list<string>& list1,const list<string>& list2, const list<string>& list3)
{
    unordered_set<string> uniqueEmails;
    list<string> mergedList;

    for(const auto& email : list1)
    {
        uniqueEmails.insert(email);
    }

    for(const auto& email : list2)
    {
        uniqueEmails.insert(email);
    }

    for(const auto& email : list3)
    {
        uniqueEmails.insert(email);
    }

    for(const auto& email : uniqueEmails)
    {
        mergedList.push_back(email);
    }
    return mergedList;
}

int main()
{
    list<string> emails1 = {"email1@example.com", "email2@example.com", "email3@example.com"};
    list<string> emails2 = {"email2@example.com", "email4@example.com"};
    list<string> emails3 = {"email3@example.com", "email5@example.com"};

    list<string> mergedEmails = mergeUnique(emails1, emails2, emails3);

    cout << "Unique email address: \n";
    for (const auto& email : mergedEmails)
    {
        cout << email << endl;
    }

    return 0;
}
