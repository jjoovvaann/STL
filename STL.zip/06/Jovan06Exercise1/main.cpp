#include<iostream>
#include<map>
#include<string>

class Uplata
{
private:
    string name;
    double amount;
public:
    Uplata(string n, double a) : name(move(n)), amount(a) {}

    string getName() const
    {
        return name;
    }

    double getAmount() const
    {
        return amount;
    }
};

int main()
{
    multimap<string, Uplata> uplati;
    int choice;

    do{
        cout<<"Menu:\n"
            "1. Add deposit\n"
            "2. Show deposit\n"
            "3. Exit\n"
            "Enter your choice: ";
        cin>> choice;

        switch (choice)
        {
        case 1:
        {
            string saverName;
            double depositAmount;

            cout << "Enter saver's name: ";
            cin >> saverName;
            cout << "Enter deposit amount: ";
            cin >> depositAmount;

            Uplata uplata(saverName, depositAmount);
            uplati.emplace(saverName, uplata);
            break;
        }
        case 2:
        {
            string searchName;
            cout << "Enter saver's name to show deposits: ";
            cin >> searchName;

            auto range = uplati.equal_range(searchName);
            if (range.first == uplati.end())
            {
                cout << "No deposits found for " << searchName << endl;
            } else
            {
                cout << "Deposits for " << searchName << ":\n";
                for (auto it = range.first; it != range.second; ++it)
                {
                    cout << "Amount: " << it->second.getAmount() <<endl;
                }
            }
            break;
        }
        case 3:
            cout << "Exiting the program. Goodbye!\n";
            break;
        default:
            cout << "Invalid choice. Please enter a valid option.\n";
        }

    }while(choice != 3);

    return 0;
}
