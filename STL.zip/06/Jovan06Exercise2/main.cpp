#include<iostream>
#include<map>

int main()
{
    map<int, int> processes;

    int numProcesses;
    cout<<"Enter the number of processes: ";
    cin>> numProcesses;

    for(int i=0;i<numProcesses;++i)
    {
        int processID, priority;
        cout<<"Enter process ID";
        cin>>processID;
        cout<<"Enter priority for process "<<processID<< ": ";
        cin>>priority;

        processes[priority] = processID;
    }

    cout<<"The order is: ";
    for(const auto& pair : processes)
    {
        cout<<"Process ID: "<<pair.second<<"priority: "<<pair.first;
    }
    return 0;
}
