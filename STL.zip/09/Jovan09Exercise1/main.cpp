#include <iostream>
#include <vector>
#include <random>
#include <algorithm>

using namespace std;

int main()
{
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> distrib(1, 999);

    try
    {
        while (true)
        {
            vector<int> vec1(distrib(gen));
            vector<int> vec2(distrib(gen));

            if (vec1.size() >= vec2.size())
            {
                copy(vec2.begin(), vec2.end(), vec1.begin());
                cout << "Копирањето е успешно извршено." << endl;
                break;
            } else
            {
                throw length_error("Големината на првиот вектор е помала од големината на вториот.");
            }
        }
    } catch (const length_error &e)
    {
        cout << "Исклучок: " << e.what() << " Пробај повторно." << endl;
    }

    return 0;
}
