#include<iostream>
#include<vector>
#include<random>
#include<algorithm>

using namespace std;

int main()
{
    const int SIZE = 100;
    vector<int> numbers(SIZE);

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0,9999);

    for(int i = 0; i < SIZE; ++i)
    {
        numbers[i] = dis(gen);
    }

    int evenCount = count_if(numbers.begin(), numbers.end(), [](int num)
    {
        return num % 2 == 0;
    });

    int lessThan2000 = count_if(numbers.begin(), numbers.end(), [](int num)
    {
        return num < 2000;
    });

    int range2000_4000 = count_if(numbers.begin(), numbers.end(), [](int num)
    {
        return num >= 2000 && num < 4000;
    });

    int range4000_6000 = count_if(numbers.begin(), numbers.end(), [](int num)
    {
        return num >= 4000 && num < 6000;
    });

    int range6000_8000 = count_if(numbers.begin(), numbers.end(), [](int num)
    {
        return num >= 6000 && num < 8000;
    });

    int range8000_10000 = count_if(numbers.begin(), numbers.end(), [](int num)
    {
        return num >= 8000 && num <= 9999;
    });

    double average = static_cast<double>(std::accumulate(numbers.begin(), numbers.end(), 0)) / SIZE;


    cout << "Number of even elements: " << evenCount << std::endl;
    cout << "Number of elements less than 2000: " << lessThan2000 << endl;
    cout << "Number of elements in [2000, 4000): " << range2000_4000 << endl;
    cout << "Number of elements in [4000, 6000): " << range4000_6000 << endl;
    cout << "Number of elements in [6000, 8000): " << range6000_8000 << endl;
    cout << "Number of elements in [8000, 10000): " << range8000_10000 << endl;
    cout << "Average value of elements: " << average << endl;

    return 0;
}
