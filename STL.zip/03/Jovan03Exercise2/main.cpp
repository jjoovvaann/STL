#include<iostream>
#include<algorithm>
#include<string>

using namespace std;

template<typename T>

class Mnozestvo
{
private:
    static const int MAX_SIZE = 100;
    T elements[MAX_SIZE];
    int count;
public:
    Mnozestvo () : count(0) {}

    bool dodadiElement(const T& element)
    {
        if(count >= MAX_SIZE)
        {
            cout<< "Full\n";
            return false;
        }
        for(int i = 0; i<count; ++1)
        {
            if(elements[i] == element)
            {
                cout<< "Already exists\n";
                return false;
            }
        }
        elements[count++] = element;
        return true;
    }
    void prikaziElementi() const
    {
        if (count == 0)
        {
            cout << "Empty.\n";
            return;
        }

        cout << "Elements: ";
        for (int i = 0; i < count; ++i)
        {
            cout << elements[i] << " ";
        }
        cout << endl;
    }

    T najgolemElement() const
    {
        if (count == 0)
        {
            cerr << "Empty.\n";
            return T();
        }

        T maxElement = elements[0];
        for (int i = 1; i < count; ++i)
        {
            if (elements[i] > maxElement)
            {
                maxElement = elements[i];
            }
        }
        return maxElement;
    }

    static int brojNaElementi()
    {
        return count;
    }
};

int main()
{
    Mnozestvo<int> A;
    Mnozestvo<double> B;
    Mnozestvo<char*> C;

    int choice;
    do {
        std::cout << "\nMenu:\n";
        std::cout << "1. Add element in A\n";
        std::cout << "2. Add element in B\n";
        std::cout << "3. Add element in C\n";
        std::cout << "4. A\n";
        std::cout << "5. B\n";
        std::cout << "6. C\n";
        std::cout << "7. Biggest element\n";
        std::cout << "8. Number of elements\n";
        std::cout << "9. End\n";
        std::cout << "Choose option: ";
        std::cin >> choice;

        switch (choice)
        {
        case 1: {
            int element;
            cout << "Add element in A: ";
            cin >> element;
            A.dodadiElement(element);
            break;
        }
        case 2:
        {
            double element;
            cout << "Add element in B: ";
            cin >> element;
            B.dodadiElement(element);
            break;
        }
        case 3:
        {
            char* element = new char[100];
            cout << "Add element in C: ";
            cin >> element;
            C.dodadiElement(element);
            break;
        }
        case 4:
            A.prikaziElementi();
            break;
        case 5:
            B.prikaziElementi();
            break;
        case 6:
            C.prikaziElementi();
            break;
        case 7:
        {
            cout << "Biggest element in A: " << A.najgolemElement() << endl;
            cout << "Biggest element in B: " << B.najgolemElement() << endl;
            char* maxString = C.najgolemElement();
            if (maxString != nullptr)
            {
                cout << "Najgolem element vo C: " << maxString << endl;
            }
            break;
        }
        case 8:
            cout << "Number of element in A: " << Mnozestvo<int>::brojNaElementi() << endl;
            cout << "Number of element in B: " << Mnozestvo<double>::brojNaElementi() << endl;
            cout << "Number of element in C: " << Mnozestvo<char*>::brojNaElementi() << endl;
            break;
        case 9:
            cout << "End.\n";
            break;
        default:
            cout << "Invalid option. Try again!\n";
            break;
        }
    } while (choice != 9);

    return 0;
}




