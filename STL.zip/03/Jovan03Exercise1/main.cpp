#include<iostream>
using namespace std;
template<typename T>

class Zapis
{
private:
    T x,y,z;

public:
    Zapis(T _x,T _y, T _z) : x(_x),y(_y),z(_z) {}

    template<typename U>
    friend bool kontrolor(const Zapis<U>& zap);
};

template<typename T>
template<typename U>

bool kontrolor(const Zapis<U>& zap)
{
    return (zap.x + zap.y + zap.z) > 10000;
}

int main()
{
    Zapis<int> zap_int(4000, 3000, 4000);
    Zapis<double> zap_double(5000.5, 3000.5, 2000.1);

    cout << "Za Zapis<int>: ";
    if (kontrolor(zap_int))
    {
        cout << "Sumata na elementite nadminuva 10000.\n";
    } else
    {
        cout << "Sumata na elementite ne nadminuva 10000.\n";
    }

    cout << "Za Zapis<double>: ";
    if (kontrolor(zap_double))
    {
        cout << "Sumata na elementite nadminuva 10000.\n";
    } else
    {
        cout << "Sumata na elementite ne nadminuva 10000.\n";
    }

    return 0;
}
