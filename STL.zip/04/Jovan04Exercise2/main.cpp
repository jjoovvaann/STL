#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

bool areAnagrams(const string& word1, const string& word2)
{
    if(word1.length() != word2.length())
    {
        return false;
    }

    vector<char> letters1(word1.begin(), word1.end());
    vector<char> letters2(word2.begin(), word2.end());

    sort(letters1.begin(), letters1.end());
    sort(letters2.begin(), letters2.end());

    return equal(letters1.begin(), letters1.end(), letters2.begin());


}

int main()
{
    string word1, word2;
    cout<<"Enter the first word";
    cin>>word1;
    cout<<"Enter the second word";
    cin>> word2;
    if(areAnagrams(word1, word2))
    {
        cout<< "Anagrams" << endl;
    }
    else
    {
        cout<<"Not anagrams"<< endl;
    }
}
