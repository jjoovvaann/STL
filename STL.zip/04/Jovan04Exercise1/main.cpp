#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

class Contact
{
public:
    string name;
    string phone_number;

    Contact(const string& n, const string& num) : name(n), phone_number(num) {}

};

class Phonebook
{
private:
    vector<Contact> contacts;

public:
    void addContact(const string& name, const string& phone_number)
    {
        contacts.emplace_back(name, phone_number);
    }

    void displayContactsInAlphabeticalOrder()
    {
        sort(contacts.begin(), contacts.end(), [](const Contact& a, const Contact& b)
        {
            return a.name < b.name;
        });

        cout << "Phonebook entries in alphabetical order:\n";
        for (const auto& contact : contacts)
        {
            cout << "Name: " << contact.name << ", Phone number: " << contact.phone_number << "\n";
        }
    }

};

int main()
{
    Phonebook phonebook;
    phonebook.addContact("Jovan", "123456");
    phonebook.addContact("Goce","1234");
    phonebook.addContact("Stojce", "23213124");

    phonebook.displayContactsInAlphabeticalOrder();

    return 0;
}




