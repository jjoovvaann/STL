#include<iostream>

using namespace std;

template<typename T, size_t size>
class Array
{
private:
    T elements[size];
public:
    void setValue(size_t index, const T& value)
    {
        if(index >= 0 && index < size)
        {
            elements[index] = value;
        }
        else
        {
            cout<<"Index out of range" << endl;
        }
    }

    T getValue(size_t index) const
    {
        if(index >= 0 && index < size)
        {
            return elements[index];
        }
        else
        {
            cout<<"Index out of range" << endl;
            return T();
        }
    }
}

int main()
{
    Array<int, 5>;
    Array<double, 3>;

    intArray.setValue(0, 10);
    intArray.setValue(1, 20);
    intArray.setValue(2, 30);

    doubleArray.setValue(0, 3.14);
    doubleArray.setValue(1, 2.718);
    doubleArray.setValue(2, 1.414);

    cout << "Int array values"<< endl;
    for (size_t i = 0; i < 3; ++i)
    {
        cout << intArray.getValue(i) << " ";
    }
    cout << endl;

    cout << "Double Array values:" << endl;
    for (size_t i = 0; i < 3; ++i)
    {
        cout << doubleArray.getValue(i) << " ";
    }
    cout << std::endl;

    return 0;
}
