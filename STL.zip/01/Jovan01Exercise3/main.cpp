// This happens because when you switch the positions of R and P, the return type (R) becomes the type of the input parameter (P).
// This might cause confusion, especially when calling the function without explicitly specifying types.
