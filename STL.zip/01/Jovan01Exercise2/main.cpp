#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

template<typename T>
int printArray(T arr[], int size, int lowSubscript, int highSubscript)
{
    if (lowSubscript < 0 || lowSubscript >= size || highSubscript < 0 || highSubscript >= size || lowSubscript > highSubscript)
    {
        return 0;
    }

    int printed = 0;
    for (int i = lowSubscript; i <= highSubscript; ++i)
    {
        std::cout << arr[i] << " ";
        printed++;
    }
    cout << endl;
    return printed;
}

template<typename T>
void sortArray(T arr[], int size)
{
    sort(arr, arr + size);
}

int main()
{
    const int size = 5;

    int a[size] = {5, 2, 9, 1, 7};
    double b[size] = {3.14, 2.718, 1.414, 1.732};
    char c[size] = {'a', 'b', 'c', 'd', 'e'};

    cout << "Print elements between indexes 1 and 3 for array 'a': ";
    int printedCount = printArray(a, size, 1, 3);
    if (printedCount == 0)
    {
        cout << "Indexes out of range or invalid!" << endl;
    } else
    {
        cout << "Number of printed elements: " << printedCount << endl;
    }

    cout << "\nPrint elements between indexes 0 and 2 for array 'b': ";
    printedCount = printArray(b, size, 0, 2);
    if (printedCount == 0)
    {
        cout << "Indexes out of range or invalid!" << endl;
    } else
    {
       cout << "Number of printed elements: " << printedCount << endl;
    }

    cout << "\nPrint elements between indexes 2 and 4 for array 'c': ";
    printedCount = printArray(c, size, 2, 4);
    if (printedCount == 0)
    {
        std::cout << "Indexes out of range or invalid!" << std::endl;
    } else
    {
        cout << "Number of printed elements: " << printedCount << endl;
    }

    return 0;
}
