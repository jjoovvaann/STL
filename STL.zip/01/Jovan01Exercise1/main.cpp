#include<iostream>
#include<algorithm>
#include<vector>

using namespace std;

template<typename T>
void sortArray(T arr[],int size)
{
    sort(arr, arr + size);
}

template<typename T>
void printArray(T arr[], int size)
{
    for(int i=0; i< size;++i )
    {
        cout<<arr[i]<<" ";
    }
    cout<< endl;
}

int main()
{
    const int intSize = 5;
    const int doubleSize = 4;

    int intArray[intSize] = {5, 2, 9, 1, 7};
    double doubleArray[doubleSize] = {3.14, 2.718, 1.414, 1.732};

    cout << "Before sorting:" << endl;
    cout << "Int array: ";
    printArray(intArray, intSize);

    cout << "Double array: ";
    printArray(doubleArray, doubleSize);

    sortArray(intArray, intSize);
    sortArray(doubleArray, doubleSize);

    cout << "\nAfter sorting:" << endl;
    cout << "Int array: ";
    printArray(intArray, intSize);

    cout << "Double array: ";
    printArray(doubleArray, doubleSize);

    return 0;

}
