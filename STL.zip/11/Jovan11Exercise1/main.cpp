#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n, m;
    cout << "Внесете го бројот n: ";
    cin >> n;
    cout << "Внесете го бројот m: ";
    cin >> m;

    cout << std::setw(m) << "i" << std::setw(m) << "i^2" << std::setw(m) << "i^3" << endl;

    cout << setfill('-') << setw(m * 3) << "-" << endl;
    cout << setfill(' ');

    cout << std::fixed << setprecision(2);

    for (int i = 1; i <= n; ++i)
    {
        cout << setw(m) << i << setw(m) << i * i << setw(m) << i * i * i << endl;
    }

    return 0;
}
