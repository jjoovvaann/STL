#include<iostream>

using namespace std;

template<typename T>
T sumArrayElements(T arr[], int startIndex, int endIndex, T initialValue = T())
{
    T sum = initialValue;
    for(int i = startIndex; i <= endIndex; i++)
    {
        sum = sum + arr[i];
    }
    return sum;
}

int main()
{
    int intArray[] = {1,2,3,4,5};
    double doubleArray[] = {1.5, 2.5, 3.5, 4.5, 5.5};

    cout << "Sum of elements in intArray: " << sumArrayElements(intArray, 1, 3) << endl;
    cout << "Sum of elements in doubleArray: " << sumArrayElements(doubleArray, 0, 2) <<endl;

    return 0;
}
