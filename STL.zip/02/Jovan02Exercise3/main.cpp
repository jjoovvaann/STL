#include<iostream>
#include<cstring>
#include<vector>

using namespace std;

template<typename T>
class Lica
{
public:
    Lica(const char* imeiprez,int matbr, int voz, const char* adr,T kod)
        : mat_br(matbr), vozrast(voz), kod(kod)
    {
        imeiprezime = new char[strlen(imeiprez) + 1];
        strcpy(imeiprezime,imeiprez);

        adresa = new char[strlen(adr) + 1];
        strcpy(adresa, adr);
    }

    ~Lica()
    {
        delete[] imeiprezime;
        delete[] adresa;
    }

    void pecatiLice() const
    {
        cout<< "Ime i prezime: "<<imeiprezime<<"Maticen broj: "<< mat_br<<
            "Vozrast "<< vozrast <<"Adresa "<< adresa <<"Kod"<<kod<<endl;
    }

private:
    char *imeiprezime;
    int mat_br;
    int vozrast;
    char *adresa;
    T kod;
};

template<typename T>
void pecatiPole(T pole[], int dolzina)
{
    for (int i = 0; i < dolzina; ++i)
    {
        pole[i].pecatiLice();
    }
}

int main()
{
    vector<Lica<int>> Vraboteni;
    vector<Lica<const char*>> Klienti;

    int choice;
    do {
        cout << "Menu:\n";
        cout << "1. Vnesuvanje na podatoci za vraboten\n";
        cout << "2. Vnesuvanje na podatoci za klient\n";
        cout << "3. Pechatenje na lista na vraboteni\n";
        cout << "4. Pechatenje na lista na klienti\n";
        cout << "5. Kraj\n";
        cout << "Izberete opcija: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            char imeiprez[50];
            int mat_br, vozrast, kod;
            char adresa[100];

            cout << "Vnesi ime i prezime: ";
            cin.ignore();
            cin.getline(imeiprez, 50);

            cout << "Vnesi matichen broj: ";
            cin >> mat_br;

            cout << "Vnesi vozrast: ";
            cin >> vozrast;

            cout << "Vnesi adresa: ";
            cin.ignore();
            cin.getline(adresa, 100);

            cout << "Vnesi kod za vraboten: ";
            cin >> kod;

            Vraboteni.emplace_back(imeiprez, mat_br, vozrast, adresa, kod);
            break;
        }
        case 2:
        {
            char imeiprez[50];
            int mat_br, vozrast;
            char adresa[100];
            char kod[20];

            cout << "Vnesi ime i prezime: ";
            cin.ignore();
            cin.getline(imeiprez, 50);

            cout << "Vnesi matichen broj: ";
            cin >> mat_br;

            cout << "Vnesi vozrast: ";
            cin >> vozrast;

            cout << "Vnesi adresa: ";
            cin.ignore();
            cin.getline(adresa, 100);

            cout << "Vnesi kod za klient: ";
            cin.ignore();
            cin.getline(kod, 20);

            Klienti.emplace_back(imeiprez, mat_br, vozrast, adresa, kod);
            break;
        }
        case 3:
            cout << "\nPechatenje na lista na vraboteni:\n";
            pecatiPole(Vraboteni.data(), Vraboteni.size());
            break;
        case 4:
            cout << "\nPechatenje na lista na klienti:\n";
            pecatiPole(Klienti.data(), Klienti.size());
            break;
        case 5:
            cout << "Kraj na programata.\n";
            break;
        default:
            cout << "Vnesovte nevalidna opcija. Obidete povtorno.\n";
            break;
        }
    } while (choice != 5);

    return 0;
}








